/********************************************************************************
** Form generated from reading UI file 'camera_settings.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CAMERA_SETTINGS_H
#define UI_CAMERA_SETTINGS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_camera_settings
{
public:
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QDoubleSpinBox *hContrast;
    QDoubleSpinBox *hSaturation;
    QDoubleSpinBox *hHue;
    QDoubleSpinBox *hGain;
    QDoubleSpinBox *hExposure;
    QDoubleSpinBox *hBrightness;
    QWidget *tab_2;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *label_7;
    QLabel *label_8;
    QDoubleSpinBox *sBrightness;
    QDoubleSpinBox *sContrast;

    void setupUi(QWidget *camera_settings)
    {
        if (camera_settings->objectName().isEmpty())
            camera_settings->setObjectName(QStringLiteral("camera_settings"));
        camera_settings->resize(181, 200);
        tabWidget = new QTabWidget(camera_settings);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 181, 201));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        formLayoutWidget = new QWidget(tab);
        formLayoutWidget->setObjectName(QStringLiteral("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(0, 0, 171, 171));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        label_4 = new QLabel(formLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_4);

        label_5 = new QLabel(formLayoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_5);

        label_6 = new QLabel(formLayoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout->setWidget(5, QFormLayout::LabelRole, label_6);

        hContrast = new QDoubleSpinBox(formLayoutWidget);
        hContrast->setObjectName(QStringLiteral("hContrast"));
        hContrast->setDecimals(2);
        hContrast->setMinimum(0);
        hContrast->setMaximum(1);
        hContrast->setSingleStep(0.01);
        hContrast->setValue(1);

        formLayout->setWidget(1, QFormLayout::FieldRole, hContrast);

        hSaturation = new QDoubleSpinBox(formLayoutWidget);
        hSaturation->setObjectName(QStringLiteral("hSaturation"));
        hSaturation->setDecimals(2);
        hSaturation->setMinimum(0);
        hSaturation->setMaximum(1);
        hSaturation->setSingleStep(0.01);
        hSaturation->setValue(1);

        formLayout->setWidget(2, QFormLayout::FieldRole, hSaturation);

        hHue = new QDoubleSpinBox(formLayoutWidget);
        hHue->setObjectName(QStringLiteral("hHue"));
        hHue->setDecimals(2);
        hHue->setMinimum(0);
        hHue->setMaximum(1);
        hHue->setSingleStep(0.01);
        hHue->setValue(0.5);

        formLayout->setWidget(3, QFormLayout::FieldRole, hHue);

        hGain = new QDoubleSpinBox(formLayoutWidget);
        hGain->setObjectName(QStringLiteral("hGain"));
        hGain->setDecimals(2);
        hGain->setMinimum(0);
        hGain->setMaximum(1);
        hGain->setSingleStep(0.01);
        hGain->setValue(1);

        formLayout->setWidget(4, QFormLayout::FieldRole, hGain);

        hExposure = new QDoubleSpinBox(formLayoutWidget);
        hExposure->setObjectName(QStringLiteral("hExposure"));
        hExposure->setDecimals(2);
        hExposure->setMinimum(0);
        hExposure->setMaximum(1);
        hExposure->setSingleStep(0.01);
        hExposure->setValue(1);

        formLayout->setWidget(5, QFormLayout::FieldRole, hExposure);

        hBrightness = new QDoubleSpinBox(formLayoutWidget);
        hBrightness->setObjectName(QStringLiteral("hBrightness"));
        hBrightness->setDecimals(2);
        hBrightness->setMinimum(-1);
        hBrightness->setMaximum(1);
        hBrightness->setSingleStep(0.01);
        hBrightness->setValue(0.5);

        formLayout->setWidget(0, QFormLayout::FieldRole, hBrightness);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        formLayoutWidget_2 = new QWidget(tab_2);
        formLayoutWidget_2->setObjectName(QStringLiteral("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(0, 0, 171, 171));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(formLayoutWidget_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_7);

        label_8 = new QLabel(formLayoutWidget_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_8);

        sBrightness = new QDoubleSpinBox(formLayoutWidget_2);
        sBrightness->setObjectName(QStringLiteral("sBrightness"));
        sBrightness->setDecimals(2);
        sBrightness->setMinimum(-100);
        sBrightness->setMaximum(100);
        sBrightness->setSingleStep(0.01);
        sBrightness->setValue(1);

        formLayout_2->setWidget(0, QFormLayout::FieldRole, sBrightness);

        sContrast = new QDoubleSpinBox(formLayoutWidget_2);
        sContrast->setObjectName(QStringLiteral("sContrast"));
        sContrast->setDecimals(2);
        sContrast->setMinimum(-100);
        sContrast->setMaximum(100);
        sContrast->setSingleStep(0.01);
        sContrast->setValue(1);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, sContrast);

        tabWidget->addTab(tab_2, QString());

        retranslateUi(camera_settings);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(camera_settings);
    } // setupUi

    void retranslateUi(QWidget *camera_settings)
    {
        camera_settings->setWindowTitle(QApplication::translate("camera_settings", "Camera Settings", nullptr));
        label->setText(QApplication::translate("camera_settings", "Brightness", nullptr));
        label_2->setText(QApplication::translate("camera_settings", "Contrast", nullptr));
        label_3->setText(QApplication::translate("camera_settings", "Saturation", nullptr));
        label_4->setText(QApplication::translate("camera_settings", "Hue", nullptr));
        label_5->setText(QApplication::translate("camera_settings", "Gain", nullptr));
        label_6->setText(QApplication::translate("camera_settings", "Exposure", nullptr));
        hContrast->setSpecialValueText(QApplication::translate("camera_settings", "0,00", nullptr));
        hSaturation->setSpecialValueText(QApplication::translate("camera_settings", "0,00", nullptr));
        hHue->setSpecialValueText(QApplication::translate("camera_settings", "0,00", nullptr));
        hGain->setSpecialValueText(QApplication::translate("camera_settings", "0,00", nullptr));
        hExposure->setSpecialValueText(QApplication::translate("camera_settings", "0,00", nullptr));
        hBrightness->setSpecialValueText(QApplication::translate("camera_settings", "0,00", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("camera_settings", "Hardware", nullptr));
        label_7->setText(QApplication::translate("camera_settings", "Brightness", nullptr));
        label_8->setText(QApplication::translate("camera_settings", "Contrast", nullptr));
        sBrightness->setSpecialValueText(QApplication::translate("camera_settings", "-", nullptr));
        sContrast->setSpecialValueText(QApplication::translate("camera_settings", "-", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("camera_settings", "Software", nullptr));
    } // retranslateUi

};

namespace Ui {
    class camera_settings: public Ui_camera_settings {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CAMERA_SETTINGS_H
