/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gui
{
public:
    QAction *ot_obj_params;
    QAction *ot_start_rec;
    QAction *ot_stop_rec;
    QAction *actionCamera_1;
    QAction *action_amera_2;
    QAction *action_amera_3;
    QAction *action_amera_4;
    QAction *action_amera_5;
    QAction *ot_camera_settings;
    QAction *Import_settings;
    QAction *Export_settings;
    QAction *ot_calibration_coordinates;
    QWidget *centralwidget;
    QLabel *label;
    QMenuBar *menubar;
    QMenu *menu_obj_track;
    QMenu *menu_Settings;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *gui)
    {
        if (gui->objectName().isEmpty())
            gui->setObjectName(QStringLiteral("gui"));
        gui->resize(724, 600);
        ot_obj_params = new QAction(gui);
        ot_obj_params->setObjectName(QStringLiteral("ot_obj_params"));
        ot_obj_params->setCheckable(false);
        ot_obj_params->setEnabled(true);
        QIcon icon;
        icon.addFile(QStringLiteral("../../gear_4053.png"), QSize(), QIcon::Normal, QIcon::Off);
        ot_obj_params->setIcon(icon);
        ot_start_rec = new QAction(gui);
        ot_start_rec->setObjectName(QStringLiteral("ot_start_rec"));
        ot_start_rec->setCheckable(false);
        ot_start_rec->setChecked(false);
        ot_start_rec->setEnabled(false);
        QIcon icon1;
        icon1.addFile(QStringLiteral("../../RecRun.png"), QSize(), QIcon::Normal, QIcon::Off);
        ot_start_rec->setIcon(icon1);
        ot_stop_rec = new QAction(gui);
        ot_stop_rec->setObjectName(QStringLiteral("ot_stop_rec"));
        ot_stop_rec->setEnabled(false);
        QIcon icon2;
        icon2.addFile(QStringLiteral("../../RecStop.png"), QSize(), QIcon::Normal, QIcon::Off);
        ot_stop_rec->setIcon(icon2);
        actionCamera_1 = new QAction(gui);
        actionCamera_1->setObjectName(QStringLiteral("actionCamera_1"));
        QIcon icon3;
        icon3.addFile(QStringLiteral("../../../../camera.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCamera_1->setIcon(icon3);
        action_amera_2 = new QAction(gui);
        action_amera_2->setObjectName(QStringLiteral("action_amera_2"));
        action_amera_2->setIcon(icon3);
        action_amera_3 = new QAction(gui);
        action_amera_3->setObjectName(QStringLiteral("action_amera_3"));
        action_amera_3->setIcon(icon3);
        action_amera_4 = new QAction(gui);
        action_amera_4->setObjectName(QStringLiteral("action_amera_4"));
        action_amera_4->setIcon(icon3);
        action_amera_5 = new QAction(gui);
        action_amera_5->setObjectName(QStringLiteral("action_amera_5"));
        action_amera_5->setIcon(icon3);
        ot_camera_settings = new QAction(gui);
        ot_camera_settings->setObjectName(QStringLiteral("ot_camera_settings"));
        QIcon icon4;
        icon4.addFile(QStringLiteral("../../camera.png"), QSize(), QIcon::Normal, QIcon::Off);
        ot_camera_settings->setIcon(icon4);
        Import_settings = new QAction(gui);
        Import_settings->setObjectName(QStringLiteral("Import_settings"));
        Export_settings = new QAction(gui);
        Export_settings->setObjectName(QStringLiteral("Export_settings"));
        ot_calibration_coordinates = new QAction(gui);
        ot_calibration_coordinates->setObjectName(QStringLiteral("ot_calibration_coordinates"));
        centralwidget = new QWidget(gui);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 0, 721, 571));
        label->setMaximumSize(QSize(721, 16777215));
        label->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0)"));
        gui->setCentralWidget(centralwidget);
        menubar = new QMenuBar(gui);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 724, 21));
        menu_obj_track = new QMenu(menubar);
        menu_obj_track->setObjectName(QStringLiteral("menu_obj_track"));
        menu_Settings = new QMenu(menubar);
        menu_Settings->setObjectName(QStringLiteral("menu_Settings"));
        gui->setMenuBar(menubar);
        statusbar = new QStatusBar(gui);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        gui->setStatusBar(statusbar);

        menubar->addAction(menu_obj_track->menuAction());
        menubar->addAction(menu_Settings->menuAction());
        menu_obj_track->addAction(ot_obj_params);
        menu_obj_track->addSeparator();
        menu_obj_track->addAction(ot_start_rec);
        menu_obj_track->addAction(ot_stop_rec);
        menu_obj_track->addSeparator();
        menu_obj_track->addSeparator();
        menu_obj_track->addAction(ot_camera_settings);
        menu_obj_track->addAction(ot_calibration_coordinates);
        menu_Settings->addAction(Import_settings);
        menu_Settings->addAction(Export_settings);

        retranslateUi(gui);

        QMetaObject::connectSlotsByName(gui);
    } // setupUi

    void retranslateUi(QMainWindow *gui)
    {
        gui->setWindowTitle(QApplication::translate("gui", "MainWindow", nullptr));
        ot_obj_params->setText(QApplication::translate("gui", "Object parameters", nullptr));
        ot_start_rec->setText(QApplication::translate("gui", "Start recording", nullptr));
        ot_stop_rec->setText(QApplication::translate("gui", "Stop recording", nullptr));
        actionCamera_1->setText(QApplication::translate("gui", "\320\241amera \342\204\2261", nullptr));
        action_amera_2->setText(QApplication::translate("gui", "\320\241amera \342\204\2262", nullptr));
        action_amera_3->setText(QApplication::translate("gui", "\320\241amera \342\204\2263", nullptr));
        action_amera_4->setText(QApplication::translate("gui", "\320\241amera \342\204\2264", nullptr));
        action_amera_5->setText(QApplication::translate("gui", "\320\241amera \342\204\2265", nullptr));
        ot_camera_settings->setText(QApplication::translate("gui", "Camera Settings", nullptr));
        Import_settings->setText(QApplication::translate("gui", "Import settings", nullptr));
        Export_settings->setText(QApplication::translate("gui", "Export settings", nullptr));
        ot_calibration_coordinates->setText(QApplication::translate("gui", "Calibration coordinates", nullptr));
        label->setText(QString());
        menu_obj_track->setTitle(QApplication::translate("gui", "Object track", nullptr));
        menu_Settings->setTitle(QApplication::translate("gui", "Settings", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gui: public Ui_gui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
